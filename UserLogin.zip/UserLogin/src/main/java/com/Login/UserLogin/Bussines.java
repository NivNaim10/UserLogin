/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Login.UserLogin;

import java.util.List;
import javax.persistence.Persistence;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author User
 */
@RestController
@RequestMapping(path="api/users")
public class Bussines {

    private final String persistenceUnitName = "UserLoginPU";
    
    /*public Bussines(String persistenceUnitName){
        this.persistenceUnitName = persistenceUnitName;
    }*/
    
    @PostMapping(path="/createNewUser")
    public void createNewUser(Users user){
        System.out.println(user);
        if(isTheUserExsist(user.getPhoneNumber()).size() != 0){
            System.out.println("This phone number is exsist in the system!");
            return;
        }
        //user = new Users(Integer.SIZE, "NivNaim", "2001", "27/12/2001", 4275858, "0507967944", 56785302);
        //PermissionsJpaController permissionsJpaController = new PermissionsJpaController(Persistence.createEntityManagerFactory(persistenceUnitName)); 
        //permissionsJpaController.create(p);
        UsersJpaController usersJpaController = new UsersJpaController(Persistence.createEntityManagerFactory(persistenceUnitName));
        usersJpaController.create(user);
    }
    
    @GetMapping(path="/loginUser")
    public Users LoginUser(String phoneNumber, String password){
        List<Users> users = isTheUserExsist(phoneNumber);
        if(users.size() == 0){
            System.out.println("The user is not exsist in the system!");
            return null;
        }
        Users user = users.get(0);
        if(user.getPassword().equals(password)){
            saveTheUserLoginTime(user.getUserID());
            return user;
        }
        System.out.println("This password is uncorrect!");
        return null;
    }
    
    public List<Users> isTheUserExsist(String phoneNumber){
        UsersJpaController usersJpaController = new UsersJpaController(Persistence.createEntityManagerFactory(persistenceUnitName));
        return usersJpaController.findUsers(phoneNumber);
    }
    
    public void saveTheUserLoginTime(Long userID){
        LoginTrackingJpaController loginTrackingJpaController = new LoginTrackingJpaController(Persistence.createEntityManagerFactory(persistenceUnitName));
        LoginTracking loginTracking = new LoginTracking();
        loginTracking.setUserID(userID);
        loginTrackingJpaController.create(loginTracking);
    }

}
