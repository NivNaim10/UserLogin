package com.Login.UserLogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserLoginApplication {

	public static void main(String[] args) {
            //Users user = new Users(Integer.SIZE, "NivNaim", "2001", "27/12/2001", 4275858, "0507967944", 56785302);           
            SpringApplication.run(UserLoginApplication.class, args);
	} 

}
